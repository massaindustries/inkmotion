"use client"

import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import { Download, Share2, RotateCcw, Play } from "lucide-react"

interface VideoResultProps {
  videoUrl: string
  onReset: () => void
}

export function VideoResult({ videoUrl, onReset }: VideoResultProps) {
  const handleDownload = () => {
    const link = document.createElement("a")
    link.href = videoUrl
    link.download = "generated-video.mp4"
    link.click()
  }

  const handleShare = async () => {
    if (navigator.share) {
      try {
        await navigator.share({
          title: "Il mio video generato con MondadorAI",
          url: videoUrl,
        })
      } catch (error) {
        console.log("Condivisione annullata")
      }
    } else {
      // Fallback: copy to clipboard
      navigator.clipboard.writeText(videoUrl)
      alert("Link copiato negli appunti!")
    }
  }

  return (
    <div className="w-full max-w-4xl mx-auto space-y-8">
      {/* Success Header */}
      <div className="text-center space-y-4">
        <div className="inline-flex items-center space-x-2 bg-green-500/10 border border-green-500/20 rounded-full px-4 py-2 text-green-300">
          <Play className="w-4 h-4" />
          <span className="text-sm">Video generato con successo!</span>
        </div>

        <h1 className="text-4xl md:text-5xl font-bold text-white">
          Il tuo video è{" "}
          <span className="bg-gradient-to-r from-green-400 to-blue-400 bg-clip-text text-transparent">pronto!</span>
        </h1>
      </div>

      {/* Video Player */}
      <Card className="bg-slate-800/50 border-slate-700/50 backdrop-blur-sm">
        <CardContent className="p-8">
          <div className="aspect-video bg-slate-900 rounded-lg overflow-hidden">
            <video
              src={videoUrl}
              controls
              className="w-full h-full object-cover"
              poster="/placeholder.svg?height=400&width=800"
            >
              Il tuo browser non supporta la riproduzione video.
            </video>
          </div>
        </CardContent>
      </Card>

      {/* Action Buttons */}
      <div className="flex flex-col sm:flex-row gap-4 justify-center">
        <Button
          onClick={handleDownload}
          className="bg-gradient-to-r from-green-600 to-blue-600 hover:from-green-700 hover:to-blue-700 text-white font-semibold py-3 px-6"
        >
          <Download className="w-5 h-5 mr-2" />
          Scarica Video
        </Button>

        <Button
          onClick={handleShare}
          variant="outline"
          className="border-slate-600 text-white hover:bg-slate-700 py-3 px-6"
        >
          <Share2 className="w-5 h-5 mr-2" />
          Condividi
        </Button>

        <Button
          onClick={onReset}
          variant="outline"
          className="border-slate-600 text-white hover:bg-slate-700 py-3 px-6"
        >
          <RotateCcw className="w-5 h-5 mr-2" />
          Crea Nuovo Video
        </Button>
      </div>
    </div>
  )
}
